<?php

namespace Home\Controller;

use Think\Controller;

class OnlineController extends Controller {    
    
    public function index() {       
        $this->display();
    }    
    public function OnlineAgainst() {       
        $this->display();
    } 
    
}
