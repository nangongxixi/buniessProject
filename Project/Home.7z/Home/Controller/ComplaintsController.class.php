<?php

namespace Home\Controller;

use Think\Controller;

class ComplaintsController extends Controller {    
    
    public function index() {        
        $this->display();
    }
    
    public function details(){
        $this->display();
    }
    
    public function detailsDes(){
        $this->display();
    }
    
    public function opinions(){
        $this->display();
    }
    
    public function evaluation(){
        $this->display();
    }
    
}
