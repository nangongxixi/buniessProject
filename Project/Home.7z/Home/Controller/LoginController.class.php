<?php

namespace Home\Controller;

use Think\Controller;

class LoginController extends Controller {    
    
    public function index() {       
        $this->display();
    }    
    public function regist() {       
        $this->display();
    }    
    public function registAgre() {       
        $this->display();    }
    public function agreement() {       
        $this->display();
    }
    
}
