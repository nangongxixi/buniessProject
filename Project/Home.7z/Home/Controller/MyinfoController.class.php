<?php

namespace Home\Controller;

use Think\Controller;

class MyinfoController extends Controller {    
    
    public function index() {        
        $this->display();
    }
    //个人信息
    public function perInfo() {        
        $this->display();
    }
    public function phone() {        
        $this->display();
    }
    public function modifyPhone() {        
        $this->display();
    }
    public function address() {        
        $this->display();
    }
    //我的信息
    public function wdInfo() {        
        $this->display();
    }
    public function systemInfo() {        
        $this->display();
    }
    //我的收藏
    public function myCollection() {        
        $this->display();
    }
    public function myJob() {        
        $this->display();
    }
    public function tousReview() {        
        $this->display();
    }
    public function about() {        
        $this->display();
    }
    public function modifyPwd() {        
        $this->display();
    }
    public function forgetPwdSur() {        
        $this->display();
    }
    public function forgetPwd() {        
        $this->display();
    }
    
    
    
}
