<?php

namespace Home\Controller;

use Think\Controller;

class NewsController extends Controller {    
    
    public function index() {       
        $this->display();
    }
    
    public function newsList() {       
        $this->display();
    }
    
    public function showNews() {       
        $this->display();
    }
    
}
